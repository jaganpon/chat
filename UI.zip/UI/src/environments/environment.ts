export const environment = {
  production: false,
  apiBase: 'http://localhost:8000/v1' // change to your backend
};
