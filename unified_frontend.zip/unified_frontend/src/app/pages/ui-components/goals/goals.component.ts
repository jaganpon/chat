import { Component } from '@angular/core';

@Component({
  selector: 'app-goal',
  template: `
    <h1>Welcome to Goals HR</h1>
    <p>Use the sidebar to navigate.</p>
  `,
})
export class GoalsComponent {}
