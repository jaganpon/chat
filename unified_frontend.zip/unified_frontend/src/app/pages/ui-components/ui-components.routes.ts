import { Routes } from '@angular/router';

// ui
import { AppBadgeComponent } from './badge/badge.component';
import { AppChipsComponent } from './chips/chips.component';
import { AppListsComponent } from './lists/lists.component';
import { AppMenuComponent } from './menu/menu.component';
import { AppTooltipsComponent } from './tooltips/tooltips.component';
import { AppFormsComponent } from './forms/forms.component';
import { AppTablesComponent } from './tables/tables.component';
import { AnalyticsComponent } from './analytics/analytics.component';
import { ChatComponent } from './chatbot/chatbot.component';
import { PerformanceComponent } from './performance/performance.component';
import { GoalsComponent } from './goals/goals.component';
import { EmployeesComponent } from './employee/employees.component';
import { ExitFormComponent } from './exit-formalities/exitForm.component';

export const UiComponentsRoutes: Routes = [
  {
    path: '',
    children: [
      {
        path: 'analytics',
        component: AnalyticsComponent,
      },
      {
        path: 'chat',
        component: ChatComponent,
      },
      {
        path: 'performance',
        component: PerformanceComponent,
      },
      {
        path: 'goals',
        component: GoalsComponent,
      },
      {
        path: 'employee',
        component: EmployeesComponent,
      },
      {
        path: 'exit-formalities',
        component: ExitFormComponent,
      },
      {
        path: 'chatbot',
        component: ChatComponent,
      },
      
      {
        path: 'badge',
        component: AppBadgeComponent,
      },
      {
        path: 'chips',
        component: AppChipsComponent,
      },
      {
        path: 'lists',
        component: AppListsComponent,
      },
      {
        path: 'menu',
        component: AppMenuComponent,
      },
      {
        path: 'tooltips',
        component: AppTooltipsComponent,
      },
      {
        path: 'forms',
        component: AppFormsComponent,
      },
      {
        path: 'tables',
        component: AppTablesComponent,
      },
    ],
  },
];
