import { Component } from '@angular/core';

@Component({
  selector: 'app-performance',
  template: `
    <h1>Welcome to TalentPulse HR</h1>
    <p>Use the sidebar to navigate.</p>
  `,
})
export class PerformanceComponent {}
