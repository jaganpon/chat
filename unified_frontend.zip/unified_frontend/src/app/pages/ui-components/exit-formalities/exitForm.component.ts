import { Component } from '@angular/core';

@Component({
  standalone: true,
  selector: 'app-employees',
  template: `
    <h1>Employees</h1>
    <p>List of employees will go here.</p>
  `,
})
export class ExitFormComponent {}
