import uuid
from fastapi import APIRouter, Depends
from typing import Optional
from sqlalchemy.orm import Session
from datetime import datetime
from database import SessionLocal, Base, engine
from schemas import MoodChatIn, MoodChatOut, MoodLogOut, MoodAnalyticsOut
from services.mood_service import MoodFlowService
from models import MoodLog

Base.metadata.create_all(bind=engine)
router = APIRouter()
flow = MoodFlowService()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/chat", response_model=MoodChatOut)
def chat(body: MoodChatIn, db: Session = Depends(get_db)):
    # Ensure user_id and session_id exist
    user_id = body.user_id or f"user_{uuid.uuid4().hex[:8]}"
    session_id = body.session_id or f"sess_{uuid.uuid4().hex[:8]}"

    reply, stage, mood, reason, extra = flow.handle(
        user_id, session_id, body.message
    )

    # Always log conversation step
    today = datetime.now().strftime("%Y-%m-%d")
    username = extra.get("username") if extra and extra.get("username") else "Anonymous"

    log = MoodLog(
        user_id=user_id,
        session_id=session_id,
        mood=mood if mood else "unknown",
        reason=reason if reason else body.message,
        date=today,
        username=username
    )
    db.add(log)
    db.commit()

    return {
        "reply": reply,
        "stage": stage,
        "user_id": user_id,
        "session_id": session_id,
        "username": extra.get("username") if extra else None
    }
@router.get("/logs", response_model=list[MoodLogOut])
def logs(user_id: Optional[str] = None, date_from: Optional[str] = None, date_to: Optional[str] = None, db: Session = Depends(get_db)):
    q = db.query(MoodLog)
    if user_id:
        q = q.filter(MoodLog.user_id == user_id)
    if date_from:
        q = q.filter(MoodLog.date >= date_from)
    if date_to:
        q = q.filter(MoodLog.date <= date_to)
    rows = q.order_by(MoodLog.created_at.desc()).all()
    return rows

@router.get("/analytics", response_model=MoodAnalyticsOut)
def analytics(
    group_by: str = "day",
    user_id: Optional[str] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    db: Session = Depends(get_db)
):
    q = db.query(MoodLog)
    if user_id:
        q = q.filter(MoodLog.user_id == user_id)
    if date_from:
        q = q.filter(MoodLog.date >= date_from)
    if date_to:
        q = q.filter(MoodLog.date <= date_to)
    rows = q.all()

    buckets = {}       # {bucket_label: {mood: count}}
    reasons = []
    global_moods = {}  # overall mood counts across all buckets

    for r in rows:
        label = None
        # support hour / day / month / year
        if group_by == "hour":
            label = r.date[:13]   # YYYY-MM-DD HH
        elif group_by == "day":
            label = r.date[:10]   # YYYY-MM-DD
        elif group_by == "month":
            label = r.date[:7]    # YYYY-MM
        elif group_by == "year":
            label = r.date[:4]    # YYYY
        else:
            label = r.date[:10]   # default = day

        if label not in buckets:
            buckets[label] = {}

        if r.mood:
            # per bucket mood count
            buckets[label][r.mood] = buckets[label].get(r.mood, 0) + 1
            # global mood count
            global_moods[r.mood] = global_moods.get(r.mood, 0) + 1

        if r.reason:
            reasons.append(r.reason)

    return {
        "buckets": buckets,       # {"2025-08-21": {"happy": 3, "sad": 1}, "2025-08-22": {"neutral": 2}, ...}
        "reasons": reasons,       # list of free-text reasons
        "top_moods": global_moods # {"happy": 10, "sad": 4, "neutral": 6}
    }

